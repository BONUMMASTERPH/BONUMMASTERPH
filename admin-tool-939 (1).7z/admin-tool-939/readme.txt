Installation: https://www.youtube.com/watch?v=buFtv9XOOd8
Preview: https://www.youtube.com/watch?v=buFtv9XOOd8

Paano gamitin: 
1. Sundan ang video ng installation para ma install ang tool.
2. Login sa router (192.168.254.254) gamit ang user account.
3. Dapat ay parehong kulay green ang icon ng Router at User na makikita sa itaas na bahagi ng tool.
4. Gamit ang tool, isa-isang subukan ang bawat band. Mag speed test bawat palit ng band hanggang sa makuha mo ang pinakamalakas na band sa lugar mo. 

PAALALA
Hindi po ako nag bibigay ng FREE ADMIN ACCESS. Ito po ay tool lamang para makapag palit kayo ng band at antenna settings gamit ang default user access na galing sa Globe. Ang tool na ito ay walang bayad at libre para sa lahat.

Pwedeng mawala ang signal sa modem nyo pag nagpalit kayo ng band (ang risk na ito ay nangyayari din kahit sa mismong admin access). Maraming pwedeng dahilan kung ba't ito nangyayari, isa na dyan ay kung hindi available o mahina ang band na napili mo sa area nyo. Madalas din ang maintenance ng globe ngayon, may mga oras na nawawala talaga ang signal kahit pa sa mga band na dati ay malakas naman. Kadalasan ay pansamantala lamang ang pagkawala ng signal, at bumabalik din naman pagkatapos ng ilang sandali. Maaring mawala ang signal sa loob ng ilang segundo o minsan ay inaabot din ng ilang oras. Minsan naayos ang problemang ito sa pag reset or pag restart ng modem. Gamitin lamang ang tool na to kung naiintindihan mo ang risk na nakapaloob dito. Minumungkahi kong basahin at unawain ang nakasulat sa license.txt file bago gamitin ang tool.